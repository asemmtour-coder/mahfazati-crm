import Link from 'next/link'
import { prisma, hasDb } from '@/lib/db'
import { NoDb, Flash } from '@/components/Notice'
import { importAccounts } from '@/app/actions'
export const dynamic = 'force-dynamic'
const PS = 25
export default async function Accounts({ searchParams: sp }: { searchParams: Record<string, string | undefined> }) {
  if (!hasDb) return <NoDb />
  const page = Math.max(1, Number(sp.page) || 1); const q = sp.q?.trim(); const region = sp.region?.trim()
  const where = { ...(q ? { OR: [{ name: { contains: q, mode: 'insensitive' as const } }, { accountNumber: { contains: q } }] } : {}), ...(region ? { region } : {}) }
  try {
    const [rows, total, regions] = await Promise.all([prisma.account.findMany({ where, orderBy: sp.sort === 'num' ? { accountNumber: 'asc' } : { name: 'asc' }, skip: (page - 1) * PS, take: PS }), prisma.account.count({ where }), prisma.account.findMany({ distinct: ['region'], select: { region: true }, where: { region: { not: null } } })])
    const pages = Math.max(1, Math.ceil(total / PS)); const qs = (p: number) => `?${new URLSearchParams({ ...(q ? { q } : {}), ...(region ? { region } : {}), ...(sp.sort ? { sort: sp.sort } : {}), page: String(p) })}`
    return (<div className="space-y-4"><h1 className="text-2xl font-extrabold">الحسابات <span className="text-sm font-normal text-slate-500">({total})</span></h1><Flash sp={sp} />
      <form action={importAccounts} className="card flex flex-wrap items-center gap-2"><input type="file" name="file" accept=".xlsx,.xls" className="text-sm" /><button className="btn">استيراد Excel</button><span className="text-xs text-slate-500">الأعمدة: رقم الحساب، اسم الحساب، المنطقة، الخطوط — والباقي يُحفظ كما هو.</span></form>
      <form className="flex flex-wrap gap-2"><input name="q" defaultValue={q} placeholder="بحث بالاسم أو الرقم" className="input max-w-xs" /><select name="region" defaultValue={region ?? ''} className="input max-w-[180px]"><option value="">كل المناطق</option>{regions.map((r) => <option key={r.region}>{r.region}</option>)}</select><select name="sort" defaultValue={sp.sort ?? 'name'} className="input max-w-[140px]"><option value="name">حسب الاسم</option><option value="num">حسب الرقم</option></select><button className="btn-ghost">تطبيق</button></form>
      <div className="card overflow-x-auto p-0"><table className="w-full"><thead><tr><th className="th">الرقم</th><th className="th">الاسم</th><th className="th">المنطقة</th><th className="th">الخطوط</th></tr></thead><tbody>
        {rows.length === 0 && <tr><td colSpan={4} className="td text-center text-slate-500">لا توجد حسابات. استورد ملف Excel للبدء.</td></tr>}
        {rows.map((a) => <tr key={a.accountNumber}><td className="td">{a.accountNumber}</td><td className="td"><Link className="text-brand hover:underline" href={`/accounts/${a.accountNumber}`}>{a.name}</Link></td><td className="td">{a.region ?? '—'}</td><td className="td">{a.linesCount}</td></tr>)}</tbody></table></div>
      <div className="flex items-center justify-center gap-3 text-sm">{page > 1 && <Link className="btn-ghost" href={qs(page - 1)}>السابق</Link>}<span>{page} / {pages}</span>{page < pages && <Link className="btn-ghost" href={qs(page + 1)}>التالي</Link>}</div></div>)
  } catch { return <div className="notice">تعذّر قراءة الحسابات. تحقق من الاتصال وأن الجداول أُنشئت.</div> }
}
