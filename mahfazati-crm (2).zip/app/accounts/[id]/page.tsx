import { notFound } from 'next/navigation'
import { prisma, hasDb, STATUS_AR, STATUS_CLS } from '@/lib/db'
import { NoDb } from '@/components/Notice'
export const dynamic = 'force-dynamic'
export default async function AccountPage({ params }: { params: { id: string } }) {
  if (!hasDb) return <NoDb />
  const a = await prisma.account.findUnique({ where: { accountNumber: decodeURIComponent(params.id) }, include: { visits: { orderBy: { visitAt: 'desc' } } } })
  if (!a) notFound()
  const extra = (a.extra ?? {}) as Record<string, unknown>
  return (<div className="space-y-4"><h1 className="text-2xl font-extrabold">{a.name}</h1>
    <div className="card grid gap-2 text-sm md:grid-cols-2"><div>رقم الحساب: <b>{a.accountNumber}</b></div><div>المنطقة: <b>{a.region ?? '—'}</b></div><div>الخطوط: <b>{a.linesCount}</b></div>{Object.entries(extra).map(([k, v]) => <div key={k}>{k}: <b>{String(v ?? '—')}</b></div>)}</div>
    <section className="card"><h2 className="mb-2 font-bold">الزيارات ({a.visits.length})</h2>{a.visits.length === 0 && <p className="text-sm text-slate-500">لا توجد زيارات لهذا الحساب.</p>}
      {a.visits.map((v) => <div key={v.id} className="border-t border-slate-100 py-2 text-sm dark:border-white/5"><div className="flex justify-between"><span>{v.visitAt.toLocaleString('ar')} · {v.type}</span><span className={`rounded-full px-2 py-0.5 text-xs ${STATUS_CLS[v.status]}`}>{STATUS_AR[v.status]}</span></div>{v.summary && <p className="text-slate-500">{v.summary}</p>}{v.followUpAt && <p className="text-xs">متابعة: {v.followUpAt.toLocaleDateString('en-CA')}</p>}{v.notes && <p className="text-xs text-slate-500">ملاحظات: {v.notes}</p>}</div>)}</section></div>)
}
