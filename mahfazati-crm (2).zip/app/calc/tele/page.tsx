import { hasDb } from '@/lib/db'
import { NoDb } from '@/components/Notice'
import CalcView from '@/components/CalcView'
export const dynamic = 'force-dynamic'
export default function Page({ searchParams }: { searchParams: Record<string, string | undefined> }) { return hasDb ? <CalcView sys="TELE" sp={searchParams} /> : <NoDb /> }
