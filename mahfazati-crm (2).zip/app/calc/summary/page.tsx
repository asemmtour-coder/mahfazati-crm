import { hasDb } from '@/lib/db'
import { NoDb } from '@/components/Notice'
import { loadCalc } from '@/lib/calc'
import { ResultsTable } from '@/components/CalcView'
export const dynamic = 'force-dynamic'
export default async function Page() {
  if (!hasDb) return <NoDb />
  try { const [m, t] = await Promise.all([loadCalc('MOBILE'), loadCalc('TELE')])
    return <div className="space-y-4"><h1 className="text-2xl font-extrabold">ملخص الاحتساب — Q{m.quarter} {m.year}</h1><ResultsTable rows={[...m.rows, ...t.rows]} /><p className="text-xs text-slate-500">كل عملية تُحتسب مرة واحدة في نظامها فقط. لا يُجمع بين العملات لعدم وجود أسعار صرف معتمدة.</p></div>
  } catch { return <div className="notice">تعذّر الاتصال بقاعدة البيانات.</div> }
}
