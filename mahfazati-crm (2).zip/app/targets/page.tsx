import { prisma, hasDb } from '@/lib/db'
import { NoDb, Flash } from '@/components/Notice'
import ConfirmButton from '@/components/ConfirmButton'
import { createTarget, updateTarget, deleteTarget } from '@/app/actions'
export const dynamic = 'force-dynamic'
const Fields = ({ t }: { t?: { name: string; number: string | null; address: string | null; notes: string | null } }) => (<><input name="name" required defaultValue={t?.name} placeholder="الاسم *" className="input" /><input name="number" defaultValue={t?.number ?? ''} placeholder="الرقم" className="input" /><input name="address" defaultValue={t?.address ?? ''} placeholder="العنوان" className="input" /><input name="notes" defaultValue={t?.notes ?? ''} placeholder="الملاحظات / النتيجة" className="input" /></>)
export default async function Targets({ searchParams: sp }: { searchParams: Record<string, string | undefined> }) {
  if (!hasDb) return <NoDb />
  try {
    const rows = await prisma.target.findMany({ orderBy: { createdAt: 'desc' } })
    return (<div className="space-y-4"><h1 className="text-2xl font-extrabold">الاستهدافات</h1><Flash sp={sp} />
      <form action={createTarget} className="card grid gap-2 md:grid-cols-5"><Fields /><button className="btn justify-center">إضافة</button></form>
      {rows.length === 0 && <div className="card text-sm text-slate-500">لا توجد استهدافات. تُضاف يدوياً فقط.</div>}
      {rows.map((t) => (<details key={t.id} className="card"><summary className="flex cursor-pointer justify-between text-sm"><b>{t.name}</b><span className="text-slate-500">{t.number} · {t.createdAt.toLocaleDateString('en-CA')}</span></summary>
        <form action={updateTarget.bind(null, t.id)} className="mt-3 grid gap-2 md:grid-cols-5"><Fields t={t} /><button className="btn justify-center">حفظ التعديل</button></form>
        <form action={deleteTarget.bind(null, t.id)} className="mt-2"><ConfirmButton label="حذف الاستهداف" msg="حذف هذا الاستهداف نهائياً؟" /></form></details>))}</div>)
  } catch { return <div className="notice">تعذّر الاتصال بقاعدة البيانات.</div> }
}
