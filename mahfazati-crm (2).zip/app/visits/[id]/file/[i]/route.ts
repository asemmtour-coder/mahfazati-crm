import { prisma } from '@/lib/db'
export async function GET(_: Request, { params }: { params: { id: string; i: string } }) {
  const v = await prisma.visit.findUnique({ where: { id: params.id } })
  const a = ((v?.attachments as { name: string; type: string; data: string }[] | null) ?? [])[Number(params.i)]
  if (!a) return new Response('غير موجود', { status: 404 })
  return new Response(Buffer.from(a.data, 'base64'), { headers: { 'Content-Type': a.type || 'application/octet-stream', 'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(a.name)}` } })
}
