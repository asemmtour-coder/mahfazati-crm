import Link from 'next/link'
import { notFound } from 'next/navigation'
import { prisma, hasDb, STATUS_AR } from '@/lib/db'
import { NoDb, Flash } from '@/components/Notice'
import { updateVisit } from '@/app/actions'
export const dynamic = 'force-dynamic'
export default async function EditVisit({ params, searchParams: sp }: { params: { id: string }; searchParams: Record<string, string | undefined> }) {
  if (!hasDb) return <NoDb />
  const v = await prisma.visit.findUnique({ where: { id: params.id }, include: { account: true } }); if (!v) notFound()
  const loc = (d: Date | null) => (d ? new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 16) : '')
  const atts = ((v.attachments as { name: string }[] | null) ?? [])
  return (<div className="space-y-4"><h1 className="text-2xl font-extrabold">تعديل زيارة — <Link className="text-brand" href={`/accounts/${v.accountNumber}`}>{v.account.name}</Link></h1><Flash sp={sp} />
    <form action={updateVisit.bind(null, v.id)} className="card grid gap-2 md:grid-cols-3"><input type="hidden" name="accountNumber" value={v.accountNumber} />
      <input name="visitAt" type="datetime-local" required defaultValue={loc(v.visitAt)} className="input" /><input name="type" required defaultValue={v.type} className="input" /><select name="status" defaultValue={v.status} className="input">{Object.entries(STATUS_AR).map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select>
      <input name="goal" defaultValue={v.goal ?? ''} placeholder="الهدف" className="input" /><input name="followUpAt" type="date" defaultValue={v.followUpAt?.toLocaleDateString('en-CA') ?? ''} className="input" /><span />
      <textarea name="summary" defaultValue={v.summary ?? ''} placeholder="ملخص الاجتماع" className="input md:col-span-3" /><textarea name="customerNeeds" defaultValue={v.customerNeeds ?? ''} placeholder="احتياجات العميل" className="input" /><textarea name="issues" defaultValue={v.issues ?? ''} placeholder="المشاكل والحلول" className="input" /><textarea name="agreedActions" defaultValue={v.agreedActions ?? ''} placeholder="الإجراءات المتفق عليها" className="input" />
      <textarea name="notes" defaultValue={v.notes ?? ''} placeholder="ملاحظات" className="input md:col-span-3" />
      <div className="md:col-span-3 text-sm">المرفقات: {atts.length === 0 && 'لا يوجد'}{atts.map((a, i) => <a key={i} className="me-3 text-brand underline" href={`/visits/${v.id}/file/${i}`}>{a.name}</a>)}</div>
      <input type="file" name="files" multiple className="text-sm md:col-span-2" /><button className="btn justify-center">حفظ التعديلات</button></form></div>)
}
