import { prisma, hasDb, STATUS_AR } from '@/lib/db'
import { NoDb, Flash } from '@/components/Notice'
import MonthView from '@/components/MonthView'
import ConfirmButton from '@/components/ConfirmButton'
import { createVisit, deleteVisit } from '@/app/actions'
export const dynamic = 'force-dynamic'
export default async function Visits({ searchParams: sp }: { searchParams: Record<string, string | undefined> }) {
  if (!hasDb) return <NoDb />
  try {
    const list = await prisma.visit.findMany({ orderBy: { visitAt: 'desc' }, take: 15, include: { account: true } })
    return (<div className="space-y-4"><h1 className="text-2xl font-extrabold">الزيارات</h1><Flash sp={sp} />
      <form action={createVisit} className="card grid gap-2 md:grid-cols-3">
        <input name="accountNumber" required placeholder="رقم الحساب *" className="input" /><input name="visitAt" type="datetime-local" required className="input" /><input name="type" required placeholder="نوع الزيارة *" className="input" />
        <input name="goal" placeholder="الهدف" className="input" /><select name="status" className="input">{Object.entries(STATUS_AR).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select><input name="followUpAt" type="date" title="تاريخ المتابعة" className="input" />
        <textarea name="summary" placeholder="ملخص الاجتماع" className="input md:col-span-3" /><textarea name="customerNeeds" placeholder="احتياجات العميل" className="input" /><textarea name="issues" placeholder="المشاكل والحلول" className="input" /><textarea name="agreedActions" placeholder="الإجراءات المتفق عليها" className="input" />
        <textarea name="notes" placeholder="ملاحظات" className="input md:col-span-2" /><button className="btn justify-center">حفظ الزيارة</button></form>
      <MonthView base="/visits" m={sp.m} />
      <section className="card"><h2 className="mb-2 font-bold">آخر الزيارات المسجّلة</h2>{list.map((v) => <form key={v.id} action={deleteVisit.bind(null, v.id)} className="flex items-center justify-between border-t border-slate-100 py-1.5 text-sm dark:border-white/5"><span>{v.visitAt.toLocaleDateString('en-CA')} · {v.account.name} · {v.type}</span><span className="flex gap-3"><a className="text-xs text-brand" href={`/visits/${v.id}`}>تعديل</a><ConfirmButton label="حذف" msg="حذف هذه الزيارة نهائياً؟" /></span></form>)}</section></div>)
  } catch { return <div className="notice">تعذّر الاتصال بقاعدة البيانات.</div> }
}
