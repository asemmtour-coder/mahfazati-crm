import './globals.css'
import { Tajawal } from 'next/font/google'
import Sidebar from '@/components/Sidebar'
const f = Tajawal({ subsets: ['arabic', 'latin'], weight: ['400', '500', '700', '800'], variable: '--font-tajawal' })
export const metadata = { title: 'محفظتي CRM' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="ar" dir="rtl" className="dark" suppressHydrationWarning><body className={`${f.variable} font-sans`}><div className="flex min-h-screen"><Sidebar /><main className="min-w-0 flex-1 p-4 md:p-8">{children}</main></div></body></html>)
}
