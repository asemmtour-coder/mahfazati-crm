import Link from 'next/link'
import { hasDb, STATUS_AR } from '@/lib/db'
import { NoDb } from '@/components/Notice'
import { reportVisits, type RSP } from '@/lib/reports'
export const dynamic = 'force-dynamic'
export default async function Reports({ searchParams: sp }: { searchParams: RSP }) {
  if (!hasDb) return <NoDb />
  try {
    const rows = await reportVisits(sp, 200); const qs = new URLSearchParams(Object.entries(sp).filter(([, v]) => v) as [string, string][]).toString()
    return (<div className="space-y-4"><h1 className="text-2xl font-extrabold">التقارير — الزيارات</h1>
      <form className="card grid gap-2 md:grid-cols-6"><input name="from" type="date" defaultValue={sp.from} className="input" title="من" /><input name="to" type="date" defaultValue={sp.to} className="input" title="إلى" /><input name="region" defaultValue={sp.region} placeholder="المنطقة" className="input" /><input name="account" defaultValue={sp.account} placeholder="رقم الحساب" className="input" />
        <select name="status" defaultValue={sp.status ?? ''} className="input"><option value="">كل الحالات</option>{Object.entries(STATUS_AR).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select><button className="btn justify-center">تطبيق</button></form>
      <div className="flex items-center justify-between text-sm"><span>{rows.length === 200 ? 'أول 200 نتيجة' : rows.length + ' نتيجة'}</span><a className="btn" href={`/reports/export?${qs}`}>تصدير Excel</a></div>
      <div className="card overflow-x-auto p-0"><table className="w-full"><thead><tr>{['التاريخ', 'الحساب', 'المنطقة', 'النوع', 'الحالة', ''].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead><tbody>
        {rows.length === 0 && <tr><td colSpan={6} className="td text-center text-slate-500">لا توجد نتائج.</td></tr>}
        {rows.map((v) => <tr key={v.id}><td className="td">{v.visitAt.toLocaleDateString('en-CA')}</td><td className="td">{v.account.name}</td><td className="td">{v.account.region ?? '—'}</td><td className="td">{v.type}</td><td className="td">{STATUS_AR[v.status]}</td><td className="td"><Link className="text-brand" href={`/visits/${v.id}`}>تعديل</Link></td></tr>)}</tbody></table></div></div>)
  } catch { return <div className="notice">تعذّر الاتصال بقاعدة البيانات.</div> }
}
