import * as XLSX from 'xlsx'
import { reportVisits, type RSP } from '@/lib/reports'
export const dynamic = 'force-dynamic'
export async function GET(req: Request) {
  const sp = Object.fromEntries(new URL(req.url).searchParams) as RSP
  const rows = (await reportVisits(sp)).map((v) => ({ 'التاريخ': v.visitAt.toISOString().slice(0, 16).replace('T', ' '), 'رقم الحساب': v.accountNumber, 'الحساب': v.account.name, 'المنطقة': v.account.region ?? '', 'النوع': v.type, 'الحالة': v.status, 'الهدف': v.goal ?? '', 'الملخص': v.summary ?? '', 'المتابعة': v.followUpAt?.toISOString().slice(0, 10) ?? '', 'ملاحظات': v.notes ?? '' }))
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), 'Visits')
  return new Response(XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }), { headers: { 'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Content-Disposition': 'attachment; filename="visits-report.xlsx"' } })
}
