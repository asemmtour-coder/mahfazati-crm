import { hasDb } from '@/lib/db'
import { NoDb } from '@/components/Notice'
import MonthView from '@/components/MonthView'
export const dynamic = 'force-dynamic'
export default function Plan({ searchParams: sp }: { searchParams: { m?: string } }) {
  if (!hasDb) return <NoDb />
  return <div className="space-y-4"><h1 className="text-2xl font-extrabold">خطة الزيارات الشهرية</h1><MonthView base="/plan" m={sp.m} onlyScheduled /></div>
}
