'use server'
import { prisma } from '@/lib/db'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { z } from 'zod'
import { parseAccounts } from '@/lib/import'

const str = (f: FormData) => Object.fromEntries([...f.entries()].filter(([, v]) => typeof v === 'string')) as Record<string, string>
const visitSchema = z.object({ accountNumber: z.string().min(1), visitAt: z.string().min(1), type: z.string().min(1), goal: z.string().optional(), summary: z.string().optional(), customerNeeds: z.string().optional(), issues: z.string().optional(), agreedActions: z.string().optional(), followUpAt: z.string().optional(), status: z.enum(['SCHEDULED', 'COMPLETED', 'POSTPONED', 'CANCELLED']), notes: z.string().optional() })

export async function createVisit(f: FormData) {
  const p = visitSchema.safeParse(str(f))
  if (!p.success) redirect('/visits?err=' + encodeURIComponent('تحقق من الحقول المطلوبة'))
  const d = p.data
  const acc = await prisma.account.findUnique({ where: { accountNumber: d.accountNumber } })
  if (!acc) redirect('/visits?err=' + encodeURIComponent('رقم الحساب غير موجود في المحفظة'))
  await prisma.visit.create({ data: { ...d, visitAt: new Date(d.visitAt), followUpAt: d.followUpAt ? new Date(d.followUpAt) : null } })
  revalidatePath('/', 'layout'); redirect('/visits')
}
export async function deleteVisit(id: string) { await prisma.visit.delete({ where: { id } }); revalidatePath('/', 'layout') }

const targetSchema = z.object({ name: z.string().min(1), number: z.string().optional(), address: z.string().optional(), notes: z.string().optional() })
export async function createTarget(f: FormData) {
  const p = targetSchema.safeParse(str(f)); if (!p.success) redirect('/targets?err=' + encodeURIComponent('الاسم مطلوب'))
  await prisma.target.create({ data: p.data }); revalidatePath('/targets'); redirect('/targets')
}
export async function updateTarget(id: string, f: FormData) {
  const p = targetSchema.safeParse(str(f)); if (!p.success) redirect('/targets?err=' + encodeURIComponent('الاسم مطلوب'))
  await prisma.target.update({ where: { id }, data: p.data }); revalidatePath('/targets'); redirect('/targets')
}
export async function deleteTarget(id: string) { await prisma.target.delete({ where: { id } }); revalidatePath('/targets') }

export async function importAccounts(f: FormData) {
  const file = f.get('file')
  if (!(file instanceof File) || file.size === 0) redirect('/accounts?err=' + encodeURIComponent('اختر ملف Excel'))
  let rows, rejected
  try { ({ rows, rejected } = parseAccounts(Buffer.from(await file.arrayBuffer()))) } catch { redirect('/accounts?err=' + encodeURIComponent('تعذّرت قراءة الملف')) }
  const res = await prisma.account.createMany({ data: rows.map((r) => ({ ...r, extra: r.extra as object })), skipDuplicates: true })
  revalidatePath('/', 'layout')
  redirect(`/accounts?ok=${res.count}&dup=${rows.length - res.count}&bad=${rejected.length}`)
}

// ---- الاحتساب ----
const CALC_PATH = { MOBILE: '/calc/mobile', TELE: '/calc/tele' } as const
const sysOf = (s: string) => (s === 'TELE' ? 'TELE' : 'MOBILE') as 'MOBILE' | 'TELE'
export async function saveRule(sys: string, key: string, f: FormData) {
  const p = String(f.get('prorate') ?? ''); const ok = f.get('confirmed') === 'on' && p !== ''
  const k = `${sys}.${key}`; const value = p === '' ? {} : { prorate: p === 'yes' }
  await prisma.calcRule.upsert({ where: { key: k }, create: { key: k, system: sys, description: key, value, confirmed: ok }, update: { value, confirmed: ok } })
  revalidatePath('/', 'layout'); redirect(CALC_PATH[sysOf(sys)])
}
export async function saveTarget(sys: string, f: FormData) {
  const s = sysOf(sys); const value = Number(f.get('value')); const cur = String(f.get('currency') ?? '')
  if (!Number.isFinite(value) || value < 0) redirect(CALC_PATH[s] + '?err=' + encodeURIComponent('قيمة الهدف غير صحيحة'))
  const now = new Date(); const year = now.getFullYear(); const quarter = Math.floor(now.getMonth() / 3) + 1
  const currency = s === 'TELE' ? (['ILS', 'USD', 'JOD'].includes(cur) ? (cur as 'ILS' | 'USD' | 'JOD') : null) : null
  if (s === 'TELE' && !currency) redirect(CALC_PATH[s] + '?err=' + encodeURIComponent('اختر العملة'))
  const ex = await prisma.calcTarget.findFirst({ where: { system: s, year, quarter, currency } })
  if (ex) await prisma.calcTarget.update({ where: { id: ex.id }, data: { value } }); else await prisma.calcTarget.create({ data: { system: s, year, quarter, value, currency } })
  revalidatePath('/', 'layout'); redirect(CALC_PATH[s])
}
export async function addOp(sys: string, f: FormData) {
  const s = sysOf(sys); const back = (m: string) => redirect(CALC_PATH[s] + '?err=' + encodeURIComponent(m))
  const amount = Number(f.get('amount')); const date = String(f.get('opDate') ?? ''); const opType = String(f.get('opType') ?? '').trim()
  const acc = String(f.get('accountNumber') ?? '').trim() || null; const notes = String(f.get('notes') ?? '') || null; const isRecurring = f.get('isRecurring') === 'on'
  if (!Number.isFinite(amount) || amount <= 0 || !date || !opType) back('تحقق من نوع العملية والتاريخ والقيمة')
  if (acc && !(await prisma.account.findUnique({ where: { accountNumber: acc } }))) back('رقم الحساب غير موجود')
  if (s === 'MOBILE') {
    if (!['ADD_NUMBER', 'UPLOAD_PROGRAM', 'ADD_DATA_PACKAGE', 'ADD_MINUTES_PACKAGE'].includes(opType)) back('نوع عملية غير معروف')
    await prisma.mobileCalculation.create({ data: { accountNumber: acc, opType: opType as 'ADD_NUMBER', opDate: new Date(date), amount, isRecurring, notes } })
  } else {
    const currency = String(f.get('currency') ?? ''); if (!['ILS', 'USD', 'JOD'].includes(currency)) back('اختر العملة')
    await prisma.teleCalculation.create({ data: { accountNumber: acc, opType, opDate: new Date(date), amount, currency: currency as 'ILS', isRecurring, notes } })
  }
  revalidatePath('/', 'layout'); redirect(CALC_PATH[s])
}
export async function deleteOp(sys: string, id: string) {
  if (sys === 'TELE') await prisma.teleCalculation.delete({ where: { id } }); else await prisma.mobileCalculation.delete({ where: { id } })
  revalidatePath('/', 'layout')
}

// ---- تعديل الزيارة + المرفقات (تُخزَّن في القاعدة: ≤1MB للملف و≤5 ملفات) ----
export async function updateVisit(id: string, f: FormData) {
  const back = (m: string) => redirect(`/visits/${id}?err=` + encodeURIComponent(m))
  const p = visitSchema.safeParse(str(f)); if (!p.success) back('تحقق من الحقول المطلوبة')
  const d = p.success ? p.data : null; if (!d) return
  const old = await prisma.visit.findUnique({ where: { id } }); if (!old) back('الزيارة غير موجودة')
  const att = [...(((old?.attachments as unknown[]) ?? []) as object[])]
  for (const x of f.getAll('files')) {
    if (!(x instanceof File) || x.size === 0) continue
    if (x.size > 1_000_000) back('الملف أكبر من 1MB'); if (att.length >= 5) back('الحد الأقصى 5 مرفقات')
    att.push({ name: x.name, type: x.type, data: Buffer.from(await x.arrayBuffer()).toString('base64') })
  }
  await prisma.visit.update({ where: { id }, data: { ...d, visitAt: new Date(d.visitAt), followUpAt: d.followUpAt ? new Date(d.followUpAt) : null, attachments: att } })
  revalidatePath('/', 'layout'); redirect('/visits')
}
