import Link from 'next/link'
import { prisma, hasDb, STATUS_AR } from '@/lib/db'
import { NoDb } from '@/components/Notice'
import { loadCalc, fmt } from '@/lib/calc'
export const dynamic = 'force-dynamic'
export default async function Dashboard() {
  if (!hasDb) return <div><h1 className="mb-4 text-2xl font-extrabold">لوحة التحكم</h1><NoDb /></div>
  try {
    const now = new Date(); const t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()); const t1 = new Date(+t0 + 864e5); const m0 = new Date(now.getFullYear(), now.getMonth(), 1); const m1 = new Date(now.getFullYear(), now.getMonth() + 1, 1)
    const open = { status: { in: ['SCHEDULED', 'POSTPONED'] as ('SCHEDULED' | 'POSTPONED')[] } }
    const [accs, lines, today, month, left, due, overdue, targets, follow, recent] = await Promise.all([
      prisma.account.count(), prisma.account.aggregate({ _sum: { linesCount: true } }),
      prisma.visit.count({ where: { visitAt: { gte: t0, lt: t1 } } }), prisma.visit.count({ where: { visitAt: { gte: m0, lt: m1 } } }),
      prisma.visit.count({ where: { visitAt: { gte: now, lt: m1 }, status: 'SCHEDULED' } }),
      prisma.visit.count({ where: { followUpAt: { gte: t0, lt: t1 }, ...open } }), prisma.visit.count({ where: { followUpAt: { lt: t0 }, ...open } }),
      prisma.target.count(),
      prisma.visit.findMany({ where: { followUpAt: { gte: t0 }, ...open }, orderBy: { followUpAt: 'asc' }, take: 10, include: { account: true } }),
      prisma.visit.findMany({ orderBy: { visitAt: 'desc' }, take: 5, include: { account: true } }),
    ])
    const stale = await prisma.account.findMany({ where: { visits: { none: { visitAt: { gte: new Date(+now - 60 * 864e5) }, status: 'COMPLETED' } } }, orderBy: { name: 'asc' }, take: 10 })
    const calc = (await Promise.all([loadCalc('MOBILE'), loadCalc('TELE')])).flatMap((c) => c.rows)
    const cards: [string, number, string][] = [['الحسابات', accs, '/accounts'], ['الخطوط', lines._sum.linesCount ?? 0, '/accounts'], ['زيارات اليوم', today, '/visits'], ['زيارات الشهر', month, '/visits'], ['المتبقية هذا الشهر', left, '/plan'], ['متابعات اليوم', due, '/visits'], ['متابعات متأخرة', overdue, '/visits'], ['الاستهدافات', targets, '/targets']]
    return (<div className="space-y-6"><h1 className="text-2xl font-extrabold">لوحة التحكم</h1>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{cards.map(([l, n, h]) => <Link key={l} href={h} className="card hover:border-brand"><div className="text-xs text-slate-500">{l}</div><div className="text-2xl font-extrabold">{n.toLocaleString('en')}</div></Link>)}</div>
      <div className="grid gap-4 md:grid-cols-2">
        <section className="card"><h2 className="mb-2 font-bold">أقرب المتابعات</h2>{follow.length === 0 ? <p className="text-sm text-slate-500">لا توجد متابعات قادمة.</p> : follow.map((v) => <div key={v.id} className="flex justify-between border-t border-slate-100 py-1.5 text-sm dark:border-white/5"><Link className="text-brand" href={`/accounts/${v.accountNumber}`}>{v.account.name}</Link><span>{v.followUpAt!.toLocaleDateString('en-CA')}</span></div>)}</section>
        <section className="card"><h2 className="mb-2 font-bold">آخر الزيارات</h2>{recent.length === 0 ? <p className="text-sm text-slate-500">لا توجد زيارات بعد.</p> : recent.map((v) => <div key={v.id} className="flex justify-between border-t border-slate-100 py-1.5 text-sm dark:border-white/5"><Link className="text-brand" href={`/accounts/${v.accountNumber}`}>{v.account.name}</Link><span>{STATUS_AR[v.status]}</span></div>)}</section>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <section className="card"><h2 className="mb-2 font-bold">حسابات بلا زيارة مكتملة منذ 60 يوماً</h2>{stale.length === 0 ? <p className="text-sm text-slate-500">لا يوجد.</p> : stale.map((a) => <div key={a.accountNumber} className="border-t border-slate-100 py-1.5 text-sm dark:border-white/5"><Link className="text-brand" href={`/accounts/${a.accountNumber}`}>{a.name}</Link></div>)}</section>
        <Link href="/calc/summary" className="card hover:border-brand"><h2 className="mb-2 font-bold">ملخص الاحتساب</h2>{calc.length === 0 ? <p className="text-sm text-slate-500">لا توجد عمليات في الكوارتر الحالي.</p> : calc.map((r) => <div key={r.label} className="text-sm">{r.label}: الفعلي {fmt(r.actual)} · الهدف {r.target === null ? 'لم يُحدَّد' : fmt(r.target)}{r.pending > 0 && ' · قواعد غير مؤكدة'}</div>)}</Link>
      </div>
      <div className="flex gap-2"><Link className="btn" href="/visits">زيارة جديدة</Link><Link className="btn-ghost" href="/accounts">استيراد حسابات</Link><Link className="btn-ghost" href="/targets">استهداف جديد</Link></div>
      </div>)
  } catch { return <div className="notice">تعذّر الاتصال بقاعدة البيانات. تحقق من .env وأن الجداول أُنشئت.</div> }
}
