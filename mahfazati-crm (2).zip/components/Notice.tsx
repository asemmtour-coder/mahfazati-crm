export function NoDb() { return <div className="notice">قاعدة البيانات غير مُعدّة: أضف DATABASE_URL و DIRECT_URL في ملف .env ثم نفّذ prisma migrate. لا تُعرض أرقام قبل ذلك.</div> }
export function Flash({ sp }: { sp: Record<string, string | undefined> }) {
  if (sp.err) return <div className="notice mb-3">{sp.err}</div>
  if (sp.ok) return <div className="card mb-3 text-sm">استُورد {sp.ok} حساباً، وتُخطّي {sp.dup} موجوداً مسبقاً، ورُفض {sp.bad} صفاً.</div>
  return null
}
