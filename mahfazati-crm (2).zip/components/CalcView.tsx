import { prisma } from '@/lib/db'
import { loadCalc, MOBILE_TYPES, ruleKeys, fmt, type Sys } from '@/lib/calc'
import { saveRule, saveTarget, addOp, deleteOp } from '@/app/actions'
import { Flash } from '@/components/Notice'
import ConfirmButton from '@/components/ConfirmButton'
export type CalcRow = Awaited<ReturnType<typeof loadCalc>>['rows'][number]
export function ResultsTable({ rows }: { rows: CalcRow[] }) {
  if (rows.length === 0) return <div className="card text-sm text-slate-500">لا توجد عمليات في الكوارتر الحالي.</div>
  return (<div className="card overflow-x-auto p-0"><table className="w-full"><thead><tr>{['النظام', 'العمليات', 'الفعلي', 'الهدف', 'الإنجاز', 'المتبقي', 'المتوقع حتى نهاية الكوارتر'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead><tbody>
    {rows.map((r) => (<tr key={r.label}><td className="td">{r.label}</td><td className="td">{r.count}</td><td className="td">{fmt(r.actual)}{r.pending > 0 && <div className="text-xs text-amber-500">{r.pending} عملية بلا قاعدة مؤكدة (غير محتسبة)</div>}</td>
      <td className="td">{r.target === null ? 'لم يُحدَّد' : fmt(r.target)}</td><td className="td">{r.pct === null ? '—' : r.pct.toFixed(1) + '%'}</td><td className="td">{r.remaining === null ? '—' : fmt(r.remaining)}</td><td className="td">{fmt(r.expected)}</td></tr>))}</tbody></table></div>)
}
export default async function CalcView({ sys, sp }: { sys: Sys; sp: Record<string, string | undefined> }) {
  try {
    const c = await loadCalc(sys); const mob = sys === 'MOBILE'
    return (<div className="space-y-4"><h1 className="text-2xl font-extrabold">{mob ? 'احتساب جوال' : 'احتساب بالتل'} <span className="text-sm font-normal text-slate-500">— Q{c.quarter} {c.year}</span></h1><Flash sp={sp} />
      <ResultsTable rows={c.rows} />
      <p className="text-xs text-slate-500">النسبي = القيمة × (الأيام من تاريخ العملية حتى نهاية الشهر ÷ أيام الشهر). التوقع للعمليات المتكررة = القيمة الشهرية الكاملة × الأشهر المتبقية ({c.monthsLeft}). لا تُحتسب أي عملية قبل تأكيد قاعدتها.</p>
      <section className="card space-y-2"><h2 className="font-bold">القواعد (تحتاج تأكيدك)</h2>
        {ruleKeys(sys).map((k) => { const r = c.rules.find((x) => x.key === `${sys}.${k}`); const v = (r?.value ?? {}) as { prorate?: boolean }; return (
          <form key={k} action={saveRule.bind(null, sys, k)} className="flex flex-wrap items-center gap-2 text-sm"><span className="w-40">{mob ? MOBILE_TYPES[k] : 'كل العمليات'}</span>
            <select name="prorate" defaultValue={v.prorate === undefined ? '' : v.prorate ? 'yes' : 'no'} className="input max-w-[220px]"><option value="">غير محدد</option><option value="yes">نسبي حتى نهاية الشهر</option><option value="no">القيمة كاملة</option></select>
            <label className="flex items-center gap-1"><input type="checkbox" name="confirmed" defaultChecked={r?.confirmed} />مؤكدة</label><button className="btn-ghost">حفظ</button></form>) })}</section>
      <form action={saveTarget.bind(null, sys)} className="card flex flex-wrap items-center gap-2"><b className="text-sm">هدف الكوارتر</b><input name="value" type="number" step="0.01" min="0" required className="input max-w-[160px]" />
        {!mob && <select name="currency" className="input max-w-[110px]"><option value="">العملة</option><option>ILS</option><option>USD</option><option>JOD</option></select>}<button className="btn-ghost">حفظ الهدف</button></form>
      <form action={addOp.bind(null, sys)} className="card grid gap-2 md:grid-cols-4"><b className="text-sm md:col-span-4">عملية جديدة</b>
        {mob ? <select name="opType" className="input">{Object.entries(MOBILE_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select> : <input name="opType" required placeholder="نوع العملية *" className="input" />}
        <input name="opDate" type="date" required className="input" /><input name="amount" type="number" step="0.01" min="0.01" required placeholder="القيمة الشهرية الكاملة *" className="input" />
        {!mob && <select name="currency" required className="input"><option value="">العملة *</option><option>ILS</option><option>USD</option><option>JOD</option></select>}
        <input name="accountNumber" placeholder="رقم الحساب (اختياري)" className="input" /><input name="notes" placeholder="ملاحظات" className="input" /><label className="flex items-center gap-2 text-sm"><input type="checkbox" name="isRecurring" />إيراد متكرر</label><button className="btn justify-center">إضافة</button></form>
      <section className="card"><h2 className="mb-2 font-bold">عمليات الكوارتر</h2>{c.ops.length === 0 && <p className="text-sm text-slate-500">لا توجد عمليات.</p>}
        {c.ops.map((o: any) => <form key={o.id} action={deleteOp.bind(null, sys, o.id)} className="flex items-center justify-between border-t border-slate-100 py-1.5 text-sm dark:border-white/5"><span>{o.opDate.toLocaleDateString('en-CA')} · {mob ? MOBILE_TYPES[o.opType] : o.opType} · {fmt(Number(o.amount))}{o.currency ? ' ' + o.currency : ''}{o.isRecurring ? ' · متكرر' : ''}</span><ConfirmButton label="حذف" msg="حذف العملية؟" /></form>)}</section></div>)
  } catch { return <div className="notice">تعذّر الاتصال بقاعدة البيانات.</div> }
}
