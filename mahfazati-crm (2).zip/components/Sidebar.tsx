'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { LayoutDashboard, Building2, CalendarCheck, CalendarDays, Crosshair, Smartphone, Phone, Sigma, BarChart3, Moon, Sun, PanelRightClose, PanelRightOpen } from 'lucide-react'
const items = [
  ['/', 'لوحة التحكم', LayoutDashboard], ['/accounts', 'الحسابات', Building2], ['/visits', 'الزيارات', CalendarCheck], ['/plan', 'خطة الزيارات', CalendarDays],
  ['/targets', 'الاستهدافات', Crosshair], ['/calc/mobile', 'احتساب جوال', Smartphone], ['/calc/tele', 'احتساب بالتل', Phone], ['/calc/summary', 'ملخص الاحتساب', Sigma], ['/reports', 'التقارير', BarChart3],
] as const
export default function Sidebar() {
  const path = usePathname(); const [open, setOpen] = useState(true); const [dark, setDark] = useState(true)
  useEffect(() => { const d = localStorage.getItem('theme') !== 'light'; setDark(d); document.documentElement.classList.toggle('dark', d); if (window.innerWidth < 768) setOpen(false) }, [])
  const toggle = () => { const d = !dark; setDark(d); localStorage.setItem('theme', d ? 'dark' : 'light'); document.documentElement.classList.toggle('dark', d) }
  return (
    <aside className={`sticky top-0 h-screen shrink-0 border-s border-slate-200 bg-white p-3 transition-all dark:border-white/10 dark:bg-[#0d1124] ${open ? 'w-56' : 'w-16'}`}>
      <div className="mb-4 flex items-center justify-between">
        {open && <span className="bg-gradient-to-l from-brand-cyan to-brand-violet bg-clip-text text-lg font-extrabold text-transparent">محفظتي CRM</span>}
        <button onClick={() => setOpen(!open)} aria-label="طي القائمة" className="rounded-lg p-2 hover:bg-slate-100 dark:hover:bg-white/10">{open ? <PanelRightClose size={18} /> : <PanelRightOpen size={18} />}</button>
      </div>
      <nav className="space-y-1">
        {items.map(([href, label, Icon]) => { const on = href === '/' ? path === '/' : path.startsWith(href); return (
          <Link key={href} href={href} title={label} className={`flex items-center gap-3 rounded-xl px-3 py-2 text-sm ${on ? 'bg-gradient-to-l from-brand/20 to-brand-violet/20 font-bold text-brand' : 'hover:bg-slate-100 dark:hover:bg-white/5'}`}><Icon size={18} />{open && label}</Link>) })}
      </nav>
      <button onClick={toggle} className="absolute bottom-3 start-3 flex items-center gap-2 rounded-xl p-2 text-sm hover:bg-slate-100 dark:hover:bg-white/10">{dark ? <Sun size={18} /> : <Moon size={18} />}{open && (dark ? 'فاتح' : 'داكن')}</button>
    </aside>
  )
}
