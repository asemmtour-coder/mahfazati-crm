'use client'
export default function ConfirmButton({ label, msg }: { label: string; msg: string }) {
  return <button type="submit" onClick={(e) => { if (!confirm(msg)) e.preventDefault() }} className="text-xs text-rose-500 hover:underline">{label}</button>
}
