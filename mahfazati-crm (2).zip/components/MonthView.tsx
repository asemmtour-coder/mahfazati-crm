import Link from 'next/link'
import { prisma, STATUS_AR, STATUS_CLS } from '@/lib/db'
export default async function MonthView({ base, m, onlyScheduled }: { base: string; m?: string; onlyScheduled?: boolean }) {
  const now = new Date(); const [y, mo] = m && /^\d{4}-\d{2}$/.test(m) ? m.split('-').map(Number) : [now.getFullYear(), now.getMonth() + 1]
  const fmt = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
  const prev = fmt(new Date(y, mo - 2, 1)), next = fmt(new Date(y, mo, 1))
  const visits = await prisma.visit.findMany({ where: { visitAt: { gte: new Date(y, mo - 1, 1), lt: new Date(y, mo, 1) }, ...(onlyScheduled ? { status: 'SCHEDULED' } : {}) }, include: { account: true }, orderBy: { visitAt: 'asc' } })
  const days = new Map<string, typeof visits>(); visits.forEach((v) => { const k = v.visitAt.toLocaleDateString('en-CA'); days.set(k, [...(days.get(k) ?? []), v]) })
  const today = now.toLocaleDateString('en-CA'); const c = (s: string) => visits.filter((v) => v.status === s).length
  return (<div className="space-y-3">
    <div className="flex items-center justify-between"><Link className="btn-ghost" href={`${base}?m=${prev}`}>الشهر السابق</Link><b>{y}-{String(mo).padStart(2, '0')}</b><Link className="btn-ghost" href={`${base}?m=${next}`}>الشهر التالي</Link></div>
    <div className="flex flex-wrap gap-2 text-xs">{Object.keys(STATUS_AR).map((s) => <span key={s} className={`rounded-full px-3 py-1 ${STATUS_CLS[s]}`}>{STATUS_AR[s]}: {c(s)}</span>)}</div>
    {days.size === 0 && <div className="card text-sm text-slate-500">لا توجد زيارات في هذا الشهر.</div>}
    {[...days].map(([k, list]) => (<div key={k} className={`card ${k === today ? 'ring-2 ring-brand' : ''}`}>
      <div className="mb-2 font-bold">{k}{k === today && ' (اليوم)'} <span className="text-xs text-slate-500">— {list.length} زيارة</span></div>
      {list.map((v) => (<div key={v.id} className="flex items-center justify-between border-t border-slate-100 py-2 text-sm dark:border-white/5">
        <span>{v.visitAt.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })} · <Link className="text-brand hover:underline" href={`/accounts/${v.accountNumber}`}>{v.account.name}</Link> · {v.type}</span>
        <span className={`rounded-full px-2 py-0.5 text-xs ${STATUS_CLS[v.status]}`}>{STATUS_AR[v.status]}</span></div>))}
    </div>))}
  </div>)
}
