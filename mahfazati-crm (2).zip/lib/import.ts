import * as XLSX from 'xlsx'
const A = { accountNumber: ['رقم الحساب', 'account_number', 'accountNumber'], name: ['اسم الحساب', 'الاسم', 'name'], region: ['المنطقة', 'region'], linesCount: ['الخطوط', 'عدد الخطوط', 'lines'] }
export type ParsedAccount = { accountNumber: string; name: string; region: string | null; linesCount: number; extra: Record<string, unknown> }
export function parseAccounts(buf: Buffer) {
  const wb = XLSX.read(buf, { type: 'buffer' })
  const raw = XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[wb.SheetNames[0]], { defval: null })
  const seen = new Set<string>(); const rows: ParsedAccount[] = []; const rejected: { row: number; reason: string }[] = []
  raw.forEach((r, i) => {
    const used = new Set<string>()
    const pick = (k: keyof typeof A) => { for (const h of A[k]) if (h in r) { used.add(h); return r[h] } return null }
    const accountNumber = String(pick('accountNumber') ?? '').trim()
    const name = String(pick('name') ?? '').trim()
    const region = String(pick('region') ?? '').trim() || null
    const n = Number(pick('linesCount') ?? 0)
    if (!accountNumber) { rejected.push({ row: i + 2, reason: 'رقم الحساب مفقود' }); return }
    if (!name) { rejected.push({ row: i + 2, reason: 'اسم الحساب مفقود' }); return }
    if (seen.has(accountNumber)) { rejected.push({ row: i + 2, reason: 'رقم حساب مكرر داخل الملف' }); return }
    seen.add(accountNumber)
    const extra = Object.fromEntries(Object.entries(r).filter(([k]) => !used.has(k)))
    rows.push({ accountNumber, name, region, linesCount: Number.isFinite(n) ? Math.trunc(n) : 0, extra })
  })
  return { rows, rejected }
}
