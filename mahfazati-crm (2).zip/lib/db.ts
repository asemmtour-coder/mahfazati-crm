import { PrismaClient } from '@prisma/client'
const g = globalThis as unknown as { prisma?: PrismaClient }
export const prisma = g.prisma ?? new PrismaClient()
if (process.env.NODE_ENV !== 'production') g.prisma = prisma
export const hasDb = !!process.env.DATABASE_URL
export const STATUS_AR: Record<string, string> = { SCHEDULED: 'مجدولة', COMPLETED: 'مكتملة', POSTPONED: 'مؤجلة', CANCELLED: 'ملغاة' }
export const STATUS_CLS: Record<string, string> = { SCHEDULED: 'bg-sky-500/15 text-sky-500', COMPLETED: 'bg-emerald-500/15 text-emerald-500', POSTPONED: 'bg-amber-500/15 text-amber-500', CANCELLED: 'bg-rose-500/15 text-rose-500' }
