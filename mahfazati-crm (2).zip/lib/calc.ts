import { prisma } from '@/lib/db'
export type Sys = 'MOBILE' | 'TELE'
export const MOBILE_TYPES: Record<string, string> = { ADD_NUMBER: 'إضافة رقم', UPLOAD_PROGRAM: 'رفع برنامج', ADD_DATA_PACKAGE: 'إضافة حزمة إنترنت', ADD_MINUTES_PACKAGE: 'إضافة حزمة دقائق' }
export const ruleKeys = (s: Sys) => (s === 'MOBILE' ? Object.keys(MOBILE_TYPES) : ['ALL'])
export const PATH: Record<Sys, string> = { MOBILE: '/calc/mobile', TELE: '/calc/tele' }
export const fmt = (n: number) => n.toLocaleString('en', { maximumFractionDigits: 2 })
// الاحتساب الفعلي: يُحتسب فقط لعملية لها قاعدة مؤكدة. نسبي = القيمة × (الأيام من تاريخ العملية حتى نهاية الشهر شاملاً ÷ أيام الشهر).
// التوقع: للعمليات المتكررة فقط = القيمة الشهرية الكاملة × الأشهر المتبقية في الكوارتر (بعد الشهر الحالي)، ومنفصل عن الفعلي.
export async function loadCalc(sys: Sys) {
  const now = new Date(); const q0 = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1); const q1 = new Date(q0.getFullYear(), q0.getMonth() + 3, 1)
  const quarter = Math.floor(q0.getMonth() / 3) + 1; const monthsLeft = 2 - (now.getMonth() - q0.getMonth())
  const where = { opDate: { gte: q0, lt: q1 } }
  const [rules, targets, ops] = await Promise.all([
    prisma.calcRule.findMany({ where: { system: sys } }), prisma.calcTarget.findMany({ where: { system: sys, year: q0.getFullYear(), quarter } }),
    (sys === 'MOBILE' ? prisma.mobileCalculation.findMany({ where, orderBy: { opDate: 'desc' } }) : prisma.teleCalculation.findMany({ where, orderBy: { opDate: 'desc' } })) as Promise<any[]>,
  ])
  const by: Record<string, { actual: number; forecast: number; count: number; pending: number }> = {}
  for (const o of ops) {
    const b = (by[sys === 'TELE' ? o.currency : '—'] ??= { actual: 0, forecast: 0, count: 0, pending: 0 }); b.count++
    const r = rules.find((x) => x.key === `${sys}.${sys === 'MOBILE' ? o.opType : 'ALL'}`); const v = (r?.value ?? {}) as { prorate?: boolean }
    if (!r?.confirmed || v.prorate === undefined) { b.pending++; continue }
    const d = new Date(o.opDate); const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); const a = Number(o.amount)
    b.actual += v.prorate ? (a * (dim - d.getDate() + 1)) / dim : a
    if (o.isRecurring) b.forecast += a * monthsLeft
  }
  const rows = Object.entries(by).map(([k, b]) => {
    const t = targets.find((x) => (sys === 'TELE' ? x.currency === k : x.currency === null)); const target = t ? Number(t.value) : null
    return { label: `${sys === 'MOBILE' ? 'جوال' : 'بالتل'}${k === '—' ? '' : ' (' + k + ')'}`, ...b, target, pct: target ? (b.actual / target) * 100 : null, remaining: target !== null ? Math.max(0, target - b.actual) : null, expected: b.actual + b.forecast }
  })
  return { ops, rows, rules, targets, quarter, year: q0.getFullYear(), monthsLeft }
}
