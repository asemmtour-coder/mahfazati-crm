import { prisma } from '@/lib/db'
import type { Prisma, VisitStatus } from '@prisma/client'
export type RSP = { from?: string; to?: string; region?: string; account?: string; status?: string }
export async function reportVisits(sp: RSP, take = 5000) {
  const where: Prisma.VisitWhereInput = {}
  if (sp.from || sp.to) where.visitAt = { ...(sp.from ? { gte: new Date(sp.from) } : {}), ...(sp.to ? { lt: new Date(+new Date(sp.to) + 864e5) } : {}) }
  if (sp.status && ['SCHEDULED', 'COMPLETED', 'POSTPONED', 'CANCELLED'].includes(sp.status)) where.status = sp.status as VisitStatus
  if (sp.account) where.accountNumber = sp.account.trim()
  if (sp.region) where.account = { region: sp.region }
  return prisma.visit.findMany({ where, include: { account: true }, orderBy: { visitAt: 'desc' }, take })
}
